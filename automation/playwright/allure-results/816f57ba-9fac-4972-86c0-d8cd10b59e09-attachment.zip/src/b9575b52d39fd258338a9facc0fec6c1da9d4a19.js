const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { DashboardPage } = require('../pages/DashboardPage');
test.describe('Q3 — E2E Apply', () => {
  test('user can apply for a job', async ({ page }) => {
    const loginPage = new LoginPage(page);
    const dashboard = new DashboardPage(page);
    const email = `e2e_${Date.now()}@test.com`;
    await loginPage.goto();
    await loginPage.register('E2E User', email, 'password123');
    await expect(dashboard.heading).toBeVisible({ timeout: 10000 });
    await dashboard.applyTab.click();
    await page.waitForSelector('select[name="jobId"]');
    await page.locator('select[name="jobId"]').selectOption({ index: 1 });
    await page.locator('input[name="fullName"]').fill('E2E User');
    await page.locator('input[name="email"]').fill(email);
    await page.locator('input[name="phone"]').fill('1234567890');
    await page.locator('input[name="city"]').fill('Dhaka');
    await page.locator('input[name="country"]').fill('Bangladesh');
    await page.locator('input[name="resumeId"]').fill('dummy-resume-id');
    await page.locator('textarea[name="coverLetter"]').fill('Automated test');
    await page.getByRole('button', { name: /Submit Application/i }).click();
    await expect(page.locator('.notice')).toContainText(/submitted/i, { timeout: 10000 });
    await page.screenshot({ path: 'screenshots/q3-application-submitted.png', fullPage: true });
  });
});
