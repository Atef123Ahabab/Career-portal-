class DashboardPage {
  constructor(page) {
    this.page = page;
    this.heading = page.getByRole('heading', { name: /Resume & Job Portal/i });
    this.jobsTab = page.getByRole('button', { name: /Job Management/i });
    this.applyTab = page.getByRole('button', { name: /Job Applications/i });
  }
  async isLoggedIn() { return await this.heading.isVisible({ timeout: 5000 }).catch(() => false); }
}
module.exports = { DashboardPage };
