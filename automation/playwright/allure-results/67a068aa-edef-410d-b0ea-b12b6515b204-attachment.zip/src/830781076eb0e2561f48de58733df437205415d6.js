class JobManagementPage {
  constructor(page) {
    this.page = page;
    this.jobTitleInput = page.locator('input[name="jobTitle"]');
    this.descriptionInput = page.locator('textarea[name="description"]');
    this.skillsInput = page.locator('input[name="requiredSkills"]');
    this.qualificationsInput = page.locator('input[name="qualifications"]');
    this.locationInput = page.locator('input[name="location"]');
    this.createButton = page.getByRole('button', { name: /Create Job/i });
  }
  async createJob({ title, description, skills, qualifications, location }) {
    await this.jobTitleInput.fill(title);
    await this.descriptionInput.fill(description);
    await this.skillsInput.fill(skills);
    await this.qualificationsInput.fill(qualifications);
    await this.locationInput.fill(location);
    await this.createButton.click();
  }
}
module.exports = { JobManagementPage };
