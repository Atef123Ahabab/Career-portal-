const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { DashboardPage } = require('../pages/DashboardPage');
const { JobManagementPage } = require('../pages/JobManagementPage');
test.describe('Q2 — Register then Create Job', () => {
  test('user can register and create a job', async ({ page }) => {
    const loginPage = new LoginPage(page);
    const dashboard = new DashboardPage(page);
    const jobPage = new JobManagementPage(page);
    const uniqueEmail = `user_${Date.now()}@test.com`;
    const uniqueTitle = `AutoTest Job ${Date.now()}`;
    await loginPage.goto();
    await loginPage.register('Playwright User', uniqueEmail, 'password123');
    await expect(dashboard.heading).toBeVisible({ timeout: 10000 });
    await page.screenshot({ path: 'screenshots/q2-dashboard-after-register.png', fullPage: true });
    await dashboard.jobsTab.click();
    await jobPage.createJob({ title: uniqueTitle, description: 'Created by Playwright', skills: 'React, Node.js', qualifications: 'BS CS', location: 'Remote' });
    await expect(page.locator('.notice')).toContainText(/successfully/i, { timeout: 5000 });
    await expect(page.getByText(uniqueTitle)).toBeVisible({ timeout: 5000 });
    await page.screenshot({ path: 'screenshots/q2-job-created.png', fullPage: true });
  });
});
